/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#4da6ff',
          DEFAULT: '#0078ff',
          dark: '#0057b8',
        },
        pink: {
          500: '#e73664',
          400: '#e95c7b',
          300: '#ef8298',
        },
        gray: {
          50: '#f9fafb',
          100: '#f3f4f6',
          200: '#e5e7eb',
          300: '#d1d5db',
          400: '#9ca3af',
          500: '#6b7280',
          600: '#4b5563',
          700: '#374151',
          800: '#1f2937',
          900: '#111827',
        },
        blue: {
          50: '#f0f7ff',
          100: '#e0effe',
          200: '#bae0fd',
          300: '#7cc5fb',
          400: '#38a8f8',
          500: '#0e8de5',
          600: '#0270c4',
          700: '#015a9e',
          800: '#064b81',
          900: '#0a406b',
        },
      },
      backgroundColor: {
        'pink-transparent': 'rgba(231, 54, 100, 0.1)',
      },
      boxShadow: {
        'card': '0px 0px 2px rgba(0, 0, 0, 0.1)',
        'nav': '0px 1px 3px rgba(0, 0, 0, 0.1)',
      },
      borderRadius: {
        'card': '28px',
        'item': '21px',
        'icon': '17px',
      },
    },
  },
  plugins: [],
}