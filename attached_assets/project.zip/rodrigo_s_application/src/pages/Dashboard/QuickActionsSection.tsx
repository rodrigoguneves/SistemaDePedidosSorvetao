import React from 'react';
import Card from '../../components/common/Card';
import { QuickActionProps } from '../../types/Dashboard';

interface ActionItemProps {
  action: QuickActionProps;
}

const ActionItem: React.FC<ActionItemProps> = ({ action }) => {
  return (
    <div 
      className="bg-[#f0f7ff] rounded-[21px] w-[151px] h-[71px] flex flex-col items-center justify-center cursor-pointer hover:bg-[#e7366419] transition-colors"
      onClick={action.onClick}
    >
      {action.icon}
      <p className="text-[12px] font-medium text-[#374151] mt-2">{action.title}</p>
    </div>
  );
};

const QuickActionsSection: React.FC = () => {
  const handleNewOrder = () => {
    alert('Criar novo pedido');
  };

  const handleAddCustomer = () => {
    alert('Adicionar novo cliente');
  };

  const handleCreateInvoice = () => {
    alert('Criar nova fatura');
  };

  const handleGenerateReport = () => {
    alert('Gerar relatório');
  };

  const quickActions: QuickActionProps[] = [
    {
      icon: <img src="/images/img_vector_pink_500_17x17.svg" alt="New Order" className="w-[17px] h-[17px]" />,
      title: "Novo Pedido",
      onClick: handleNewOrder
    },
    {
      icon: <img src="/images/img_vector_pink_500_10x13.svg" alt="Add Customer" className="w-[17px] h-[22px]" />,
      title: "Adicionar Cliente",
      onClick: handleAddCustomer
    },
    {
      icon: <img src="/images/img_vector_pink_500_17x13.svg" alt="Create Invoice" className="w-[17px] h-[13px]" />,
      title: "Criar Fatura",
      onClick: handleCreateInvoice
    },
    {
      icon: <img src="/images/img_frame_pink_500_17x20.svg" alt="Generate Report" className="w-[17px] h-[20px]" />,
      title: "Gerar Relatório",
      onClick: handleGenerateReport
    }
  ];

  return (
    <Card className="w-[355px] h-[373px]">
      <div className="p-5">
        <h2 className="text-[16px] font-semibold text-[#1f2937] mb-4">Ações Rápidas</h2>
        
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map((action, index) => (
            <ActionItem key={index} action={action} />
          ))}
        </div>
      </div>
    </Card>
  );
};

export default QuickActionsSection;