import React from 'react';
import Card from '../../components/common/Card';
import ProgressBar from '../../components/ui/ProgressBar';
import { FinancialAccountProps, FinancialSummaryProps } from '../../types/Dashboard';

interface AccountItemProps {
  account: FinancialAccountProps;
}

const AccountItem: React.FC<AccountItemProps> = ({ account }) => {
  return (
    <div className="bg-[#f0f7ff] rounded-[21px] p-3 mb-4 flex items-center justify-between">
      <div className="flex items-center">
        {account.icon}
        <span className="text-[12px] text-[#1f2937] ml-2">{account.title}</span>
      </div>
      <span className="text-[14px] font-bold text-[#1f2937]">{account.value}</span>
    </div>
  );
};

interface SummaryItemProps {
  summary: FinancialSummaryProps;
}

const SummaryItem: React.FC<SummaryItemProps> = ({ summary }) => {
  return (
    <div className="bg-[#f0f7ff] rounded-[21px] p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[12px] text-[#4b5563]">Receita Total</span>
        <span className="text-[14px] font-bold text-[#1f2937]">{summary.revenue}</span>
      </div>
      
      <ProgressBar 
        progress={summary.revenuePercentage} 
        height={8} 
        color="#e73664" 
        backgroundColor="#e5e7eb" 
        className="mb-4"
      />
      
      <div className="flex items-center justify-between mb-2">
        <span className="text-[12px] text-[#4b5563]">Despesas Totais</span>
        <span className="text-[14px] font-bold text-[#1f2937]">{summary.expenses}</span>
      </div>
      
      <ProgressBar 
        progress={summary.expensesPercentage} 
        height={8} 
        color="#6b7280" 
        backgroundColor="#e5e7eb"
      />
    </div>
  );
};

const FinancialSection: React.FC = () => {
  const accounts: FinancialAccountProps[] = [
    {
      icon: <img src="/images/img_vector_pink_500_14x14.svg" alt="Bank" className="w-[14px] h-[14px]" />,
      title: "Conta Bancária Principal",
      value: "R$ 17.250"
    },
    {
      icon: <img src="/images/img_frame_pink_500.svg" alt="Cash" className="w-[14px] h-[16px]" />,
      title: "Dinheiro em Caixa",
      value: "R$ 3.450"
    }
  ];

  const financialSummary: FinancialSummaryProps = {
    revenue: "R$ 54.200",
    expenses: "R$ 28.500",
    revenuePercentage: 75, // Calculated as percentage of max width
    expensesPercentage: 40  // Calculated as percentage of max width
  };

  return (
    <Card className="w-[355px] h-[373px]">
      <div className="p-5">
        <h2 className="text-[16px] font-semibold text-[#1f2937] mb-3">Resumo Financeiro</h2>
        
        <div className="mb-4">
          <p className="text-[12px] font-medium text-[#6b7280] mb-3">Saldos de Contas Principais</p>
          
          {accounts.map((account, index) => (
            <AccountItem key={index} account={account} />
          ))}
        </div>
        
        <div>
          <p className="text-[12px] font-medium text-[#6b7280] mb-3">Receita vs. Despesas (Mês Atual)</p>
          <SummaryItem summary={financialSummary} />
        </div>
      </div>
    </Card>
  );
};

export default FinancialSection;