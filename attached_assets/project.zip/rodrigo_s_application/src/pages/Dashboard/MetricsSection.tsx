import React from 'react';
import Card from '../../components/common/Card';
import { MetricCardProps } from '../../types/Dashboard';

const MetricCard: React.FC<MetricCardProps> = ({ icon, title, value, subtitle }) => {
  return (
    <Card className="h-[128px] w-[266px]">
      <div className="p-4">
        <div className="flex items-start">
          <div className="w-[35px] h-[35px] rounded-[17px] bg-[#e7366419] flex items-center justify-center">
            {icon}
          </div>
          <div className="ml-3">
            <p className="text-[12px] text-[#6b7280]">{title}</p>
          </div>
        </div>
        <div className="mt-3">
          <p className="text-[21px] font-bold text-[#1f2937]">{value}</p>
          <p className="text-[10px] text-[#9ca3af] mt-1">{subtitle}</p>
        </div>
      </div>
    </Card>
  );
};

const MetricsSection: React.FC = () => {
  const metrics = [
    {
      icon: <img src="/images/img_vector_pink_500_16x9.svg" alt="Sales" className="w-4 h-4" />,
      title: "Vendas Totais",
      value: "R$ 47.600",
      subtitle: "Mês Atual"
    },
    {
      icon: <img src="/images/img_vector_pink_500_16x17.svg" alt="Orders" className="w-4 h-4" />,
      title: "Novos Pedidos",
      value: "14",
      subtitle: "Hoje / Esta Semana"
    },
    {
      icon: <img src="/images/img_vector_pink_500_21x26.svg" alt="Customers" className="w-4 h-4" />,
      title: "Clientes Ativos",
      value: "28",
      subtitle: "Mês Atual"
    },
    {
      icon: <img src="/images/img_vector_pink_500_14x18.svg" alt="Payments" className="w-4 h-4" />,
      title: "Pagamentos Pendentes",
      value: "R$ 12.850",
      subtitle: "De Pedidos B2B"
    }
  ];

  return (
    <div className="flex space-x-6 mb-6">
      {metrics.map((metric, index) => (
        <MetricCard key={index} {...metric} />
      ))}
    </div>
  );
};

export default MetricsSection;