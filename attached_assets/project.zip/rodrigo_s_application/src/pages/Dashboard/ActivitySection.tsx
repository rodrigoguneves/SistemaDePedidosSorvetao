import React from 'react';
import Card from '../../components/common/Card';
import { RecentOrderProps, PendingTaskProps } from '../../types/Dashboard';

interface OrderItemProps {
  order: RecentOrderProps;
}

const OrderItem: React.FC<OrderItemProps> = ({ order }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'processing': return 'text-[#6b7280]';
      case 'shipped': return 'text-[#6b7280]';
      case 'completed': return 'text-[#6b7280]';
      default: return 'text-[#6b7280]';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'processing': return 'Em Processamento';
      case 'shipped': return 'Enviado';
      case 'completed': return 'Concluído';
      default: return status;
    }
  };

  return (
    <div className="bg-[#f0f7ff] rounded-[21px] p-3 mb-4 flex items-center">
      <div className="w-[28px] h-[28px] rounded-[14px] bg-[#e7366419] flex items-center justify-center">
        <img src="/images/img_vector_pink_500_9x9.svg" alt="Order" className="w-[9px] h-[9px]" />
      </div>
      <div className="ml-4">
        <p className="text-[12px] font-medium text-[#1f2937]">{order.customer}</p>
        <p className={`text-[10px] ${getStatusColor(order.status)}`}>
          {getStatusText(order.status)}
        </p>
      </div>
    </div>
  );
};

interface TaskItemProps {
  task: PendingTaskProps;
}

const TaskItem: React.FC<TaskItemProps> = ({ task }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-[#e73664]';
      case 'medium': return 'bg-[#e7366419]';
      case 'low': return 'bg-[#e7366419]';
      default: return 'bg-[#e7366419]';
    }
  };

  const getPriorityText = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'Urgente';
      case 'medium': return 'Prioridade Média';
      case 'low': return 'Prioridade Baixa';
      default: return priority;
    }
  };

  return (
    <div className={`${task.priority === 'urgent' ? 'bg-[#e7366419]' : 'bg-[#f0f7ff]'} rounded-[21px] p-3 mb-4 flex items-center`}>
      <div className={`w-[28px] h-[28px] rounded-[14px] ${getPriorityColor(task.priority)} flex items-center justify-center`}>
        {task.priority === 'urgent' ? (
          <img src="/images/img_vector_white_a700.png" alt="Urgent" className="w-[9px] h-[1px]" />
        ) : (
          <img src="/images/img_vector_pink_500_10x13.svg" alt="Task" className="w-[10px] h-[13px]" />
        )}
      </div>
      <div className="ml-4">
        <p className="text-[12px] font-medium text-[#1f2937]">{task.title}</p>
        <p className="text-[10px] text-[#6b7280]">{getPriorityText(task.priority)}</p>
      </div>
    </div>
  );
};

const ActivitySection: React.FC = () => {
  const recentOrders: RecentOrderProps[] = [
    { id: '534', customer: 'Pedido #534 - Delícias Doces', status: 'processing' },
    { id: '533', customer: 'Pedido #533 - Paraíso do Gelo', status: 'shipped' },
    { id: '532', customer: 'Pedido #532 - Gelados Refrescantes', status: 'completed' }
  ];

  const pendingTasks: PendingTaskProps[] = [
    { id: '1', title: '3 Pedidos Aguardando Atendimento', priority: 'urgent', count: 3 },
    { id: '2', title: '2 Clientes Aguardando Configuração', priority: 'medium', count: 2 }
  ];

  return (
    <Card className="w-[355px] h-[458px]">
      <div className="p-5">
        <h2 className="text-[16px] font-semibold text-[#1f2937] mb-4">Atividade Recente</h2>
        
        <div className="mb-4">
          <div className="flex items-center mb-2">
            <img src="/images/img_vector_pink_500_12x12.svg" alt="Orders" className="w-[12px] h-[12px]" />
            <span className="text-[12px] font-medium text-[#6b7280] ml-2">Pedidos Recentes</span>
          </div>
          
          {recentOrders.map(order => (
            <OrderItem key={order.id} order={order} />
          ))}
        </div>
        
        <div>
          <div className="flex items-center mb-2">
            <img src="/images/img_vector_pink_500_12x10.svg" alt="Tasks" className="w-[12px] h-[10px]" />
            <span className="text-[12px] font-medium text-[#6b7280] ml-2">Tarefas Pendentes</span>
          </div>
          
          {pendingTasks.map(task => (
            <TaskItem key={task.id} task={task} />
          ))}
        </div>
      </div>
    </Card>
  );
};

export default ActivitySection;