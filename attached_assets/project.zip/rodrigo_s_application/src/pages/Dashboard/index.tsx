import React from 'react';
import Header from '../../components/common/Header';
import Footer from '../../components/common/Footer';
import Card from '../../components/common/Card';
import Button from '../../components/ui/Button';
import MetricsSection from './MetricsSection';
import ActivitySection from './ActivitySection';
import FinancialSection from './FinancialSection';
import QuickActionsSection from './QuickActionsSection';

const Dashboard: React.FC = () => {
  const handleCreateOrder = () => {
    alert('Criar novo pedido');
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(134deg,#f0f7ff_0%,#afc7e0_100%)]">
      <Header />
      
      <main className="container mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-[26px] font-bold text-[#1f2937]">Painel do Sistema</h1>
          
          <Button 
            variant="primary" 
            size="md"
            onClick={handleCreateOrder}
            className="h-[50px] px-8"
            icon={<img src="/images/img_frame.svg" alt="Add" className="w-[10px] h-[12px]" />}
          >
            Criar Novo Pedido
          </Button>
        </div>
        
        <MetricsSection />
        
        <div className="flex space-x-6 mb-6">
          <Card className="w-[732px] h-[458px]">
            <div className="p-5">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-[16px] font-semibold text-[#1f2937]">Tendência de Receita de Vendas</h2>
                <span className="text-[10px] text-[#6b7280]">Últimos 30 Dias</span>
              </div>
              
              {/* This would be a chart component in a real application */}
              <div className="w-full h-[380px] flex items-center justify-center bg-[#f0f7ff] rounded-lg">
                <p className="text-[14px] text-[#6b7280]">Gráfico de tendência de vendas seria exibido aqui</p>
              </div>
            </div>
          </Card>
          
          <ActivitySection />
        </div>
        
        <div className="flex space-x-6">
          <FinancialSection />
          
          <Card className="w-[355px] h-[373px]">
            <div className="p-5">
              <h2 className="text-[16px] font-semibold text-[#1f2937]">Categorias Mais Vendidas</h2>
              
              {/* This would be a chart component in a real application */}
              <div className="w-full h-[300px] flex items-center justify-center bg-[#f0f7ff] rounded-lg mt-4">
                <p className="text-[14px] text-[#6b7280]">Gráfico de categorias seria exibido aqui</p>
              </div>
            </div>
          </Card>
          
          <QuickActionsSection />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;