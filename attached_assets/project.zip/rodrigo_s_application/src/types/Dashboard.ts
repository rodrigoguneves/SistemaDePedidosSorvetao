export interface MetricCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  subtitle: string;
}

export interface RecentOrderProps {
  id: string;
  customer: string;
  status: 'processing' | 'shipped' | 'completed';
}

export interface PendingTaskProps {
  id: string;
  title: string;
  priority: 'urgent' | 'medium' | 'low';
  count?: number;
}

export interface FinancialAccountProps {
  icon: React.ReactNode;
  title: string;
  value: string;
}

export interface FinancialSummaryProps {
  revenue: string;
  expenses: string;
  revenuePercentage: number;
  expensesPercentage: number;
}

export interface QuickActionProps {
  icon: React.ReactNode;
  title: string;
  onClick: () => void;
}