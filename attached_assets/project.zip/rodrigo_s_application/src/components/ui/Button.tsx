import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  icon?: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  className = '',
  icon
}) => {
  const baseClasses = 'flex items-center justify-center rounded-[25px] font-semibold transition-colors';
  
  const variantClasses = {
    primary: 'bg-[#e73664] text-white',
    secondary: 'bg-[#f0f7ff] text-[#374151]',
    outline: 'bg-transparent border border-[#e73664] text-[#e73664]'
  };
  
  const sizeClasses = {
    sm: 'text-[12px] py-2 px-3',
    md: 'text-[14px] py-3 px-4',
    lg: 'text-[16px] py-4 px-6'
  };
  
  return (
    <button
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      onClick={onClick}
    >
      {icon && <span className="mr-2">{icon}</span>}
      {children}
    </button>
  );
};

export default Button;