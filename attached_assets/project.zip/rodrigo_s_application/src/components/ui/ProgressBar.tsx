import React from 'react';

interface ProgressBarProps {
  progress: number;
  height?: number;
  color?: string;
  backgroundColor?: string;
  className?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  height = 8,
  color = '#e73664',
  backgroundColor = '#e5e7eb',
  className = ''
}) => {
  // Ensure progress is between 0 and 100
  const validProgress = Math.min(Math.max(progress, 0), 100);
  
  return (
    <div 
      className={`w-full rounded-[4px] ${className}`} 
      style={{ height: `${height}px`, backgroundColor }}
    >
      <div 
        className="h-full rounded-[4px] transition-all duration-300 ease-in-out"
        style={{ 
          width: `${validProgress}%`, 
          backgroundColor: color 
        }}
      />
    </div>
  );
};

export default ProgressBar;