import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="h-[40px] w-full bg-white shadow-[0px_-1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center">
      <p className="text-[12px] text-[#9ca3af]">
        © 2025 Sorvetão. Todos os direitos reservados.
      </p>
    </footer>
  );
};

export default Footer;