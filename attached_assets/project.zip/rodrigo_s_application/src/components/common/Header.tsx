import React from 'react';
import { Link } from 'react-router-dom';

interface NavItemProps {
  icon: string;
  label: string;
  isActive?: boolean;
  href: string;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, isActive = false, href }) => {
  return (
    <div className="flex flex-col items-center mx-2">
      <Link to={href}>
        <div className={`w-[49px] h-[49px] rounded-[24px] flex items-center justify-center ${isActive ? 'bg-[#e73664]' : 'bg-[#f1e6e2]'} ${!isActive && 'shadow-[0px_1px_3px_rgba(0,0,0,0.1)]'}`}>
          <img src={icon} alt={label} className="w-[21px]" />
        </div>
        <p className={`text-[10px] font-bold mt-1 text-center ${isActive ? 'text-[#e73664]' : 'text-[#6b7280]'}`}>
          {label}
        </p>
      </Link>
    </div>
  );
};

const Header: React.FC = () => {
  return (
    <header className="h-[100px] w-full bg-white shadow-[0px_1px_2px_rgba(0,0,0,0.1)] flex items-center justify-between px-4">
      <div className="flex items-center">
        <img src="/images/img_div.svg" alt="Sorvetão Logo" className="h-[42px]" />
      </div>
      
      <div className="flex items-center space-x-2">
        <NavItem 
          icon="/images/img_vector.svg" 
          label="Painel" 
          isActive={true} 
          href="/dashboard"
        />
        <NavItem 
          icon="/images/img_vector_pink_500.svg" 
          label="Produtos" 
          href="/products"
        />
        <NavItem 
          icon="/images/img_vector_pink_500_21x26.svg" 
          label="Clientes" 
          href="/customers"
        />
        <NavItem 
          icon="/images/img_vector_pink_500_21x16.svg" 
          label="Pedidos" 
          href="/orders"
        />
        <NavItem 
          icon="/images/img_vector_pink_500_18x21.svg" 
          label="Financeiro" 
          href="/financial"
        />
        <NavItem 
          icon="/images/img_vector_pink_500_21x20.svg" 
          label="Opções" 
          href="/options"
        />
      </div>
      
      <div className="flex items-center">
        <span className="text-[12px] font-medium text-[#374151] mr-3">João Administrador</span>
        <img src="/images/img_img.png" alt="Profile" className="w-[35px] h-[35px] rounded-[17px]" />
        <div className="w-[35px] h-[35px] rounded-[17px] bg-[#f0f7ff] flex items-center justify-center ml-2">
          <img src="/images/img_vector_gray_600.svg" alt="Settings" className="w-[12px] h-[14px]" />
        </div>
      </div>
    </header>
  );
};

export default Header;