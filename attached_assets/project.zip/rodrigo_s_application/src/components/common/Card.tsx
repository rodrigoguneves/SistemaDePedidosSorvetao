import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div className={`bg-white rounded-[28px] shadow-[0px_0px_2px_rgba(0,0,0,0.1)] ${className}`}>
      {children}
    </div>
  );
};

export default Card;